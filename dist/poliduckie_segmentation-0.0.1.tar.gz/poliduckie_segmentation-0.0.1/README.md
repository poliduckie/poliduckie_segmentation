# poliduckie_segmentation
A package ready to be installed that provides the segmentation work made by the Poliduckie team

### Example
```python
from poliduckie_segmentation.segmentation import Segmentation

image = [...]
segmentation = Segmentation()
prediction = segmentation.predict(image)
```
