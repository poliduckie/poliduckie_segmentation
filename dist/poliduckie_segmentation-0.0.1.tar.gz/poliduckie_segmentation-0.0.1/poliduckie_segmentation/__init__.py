from poliduckie_segmentation.segmentation import Segmentation

__version__ = '0.0.1'
__author__ = 'PoliDuckies'
__email__ = 'duckietown@aeapolimi.it'
__license__ = 'MIT'
__url__ = 'github.com/poliduckie/poliduckie_segmentation'